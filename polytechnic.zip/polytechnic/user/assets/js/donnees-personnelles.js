var dp={
	defaultPays:"FR",
	hide:function(e,s){"use strict";e.prop("disabled",!0),s.hide(0)},
	show:function(e,s){"use strict";e.prop("disabled",!1),s.show(0)},
	exist:function(e,s){"use strict";return-1!==$.inArray(e.val(),s)}
};


$(function(){"use strict";var i,t,e=$("#btn-single"),s=$("#btn-couple"),a=$("#infoForm"),n=$("#idSous"),r=$("#email"),o=$("#confirmEmail"),l=$("#nom"),m=$("#prenom"),d=$("#today"),p=($(".modal-sauvegarde-ecran1"),$("#salaireMin").val()),c=$("#soldeAccesMin").val(),u=$("#soldeAccesMinJoint").val(),g=$("#soldeIndividuelMin").val(),v=$("#soldeJointMin").val(),f=/^[^<|>|\*|!|\$|°|;|¨|,|\/|\\|\(|\)|\||=|\&|\?|%|;|0-9|@]*$/,h=/^[^<|>|\*|!|\$|°|;|,|\/|\\|\(|\)|\||=|\&|\?|%|@]*$/,
	y={fields:{
		civilite:{validators:{notEmpty:{message:messages.dpers.civilite}}},
		nomJeuneFille:{validators:{regexp:{regexp:f,message:messages.dpers.alphabetic},notEmpty:{message:messages.dpers.nomJeuneFilleRequis}}},
		nom:{validators:{regexp:{regexp:f,message:messages.dpers.alphabetic},notEmpty:{message:messages.dpers.nomRequis}}},
		prenom:{validators:{regexp:{regexp:f,message:messages.dpers.alphabetic},notEmpty:{message:messages.dpers.prenomRequis}}},
		dateNaissance:{validators:{callback:{callback:function(e){var s=moment(e,"DD/MM/YYYY"),a=moment(d.val(),"DD/MM/YYYY"),i=moment(d.val(),"DD/MM/YYYY").subtract(18,"years"),t=moment("01/01/1900","DD/MM/YYYY");return!e||(!s.isValid()||(s.isBefore(a)||s.isSame(a)?s.isAfter(i)?{message:messages.dpers.dateNaissance,valid:!1}:!s.isBefore(t)||{message:messages.dpers.dateTropAncienne,valid:!1}:{message:messages.dpers.dateNaissance,valid:!1}))}},date:{format:"DD/MM/YYYY"},stringLength:{min:10,max:10,message:messages.dpers.birthDateValid,valid:!1},notEmpty:{message:messages.dpers.dateNaissanceRequis}}},
		paysNaissance:{validators:{callback:{message:messages.dpers.paysEU,callback:function(e){return"US"!==e}}}},
		pays:{validators:{callback:{message:messages.dpers.residenceEU,callback:function(e){return"US"!==e}}}},
		villeNaissance:{validators:{regexp:{regexp:h,message:messages.dpers.numeric},notEmpty:{message:messages.dpers.villeNaissanceRequis}}},
		nationalite:{validators:{callback:{message:messages.dpers.nationaliteEU,callback:function(e){return"US"!==e}}}},
		departementNaissance:{validators:{regexp:{regexp:/^(([\d]{2,3})|(2[abAB])){0,1}$/,message:messages.dpers.departementNaissance},notEmpty:{message:messages.dpers.departementNaissanceRequis}}},
		arrondissementNaissance:{validators:{notEmpty:{message:messages.dpers.arrondissementNaissanceRequis}}},
		questionSecrete:{validators:{regexp:{regexp:f,message:messages.dpers.alphabetic},notEmpty:{message:messages.dpers.nomMereRequis}}},
		adresse:{validators:{regexp:{regexp:/^[^<|>|\*|!|\$|°|;|\/|\\|\(|\)|\||=|\&|\?|%|@]*$/,message:messages.dpers.numeric},notEmpty:{message:messages.dpers.adresseRequis}}},
		complementAdresse:{validators:{regexp:{regexp:h,message:messages.dpers.numeric}}},
		codePostal:{validators:{regexp:{regexp:/^\d{5}$/,message:messages.dpers.codePostal},notEmpty:{message:messages.dpers.codePostalRequis}}},
		ville:{validators:{regexp:{regexp:h,message:messages.dpers.numeric},notEmpty:{message:messages.dpers.villeRequis}}},
		email:{validators:{notEmpty:{message:messages.dpers.emailRequis},regexp:{regexp:/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,message:messages.dpers.emailFormat}}},
		confirmEmail:{validators:{notEmpty:{message:messages.dpers.emailRequis},callback:{callback:function(e){return e.toUpperCase()===$("#email").val().toUpperCase()},message:messages.dpers.emailIdentique}}},
		
		telephonePortable:{validators:{regexp:{regexp:/^\+\d{1,4}\s{0}\d{6,14}$/,message:messages.dpers.telephone},notEmpty:{message:messages.dpers.telephone}}},
		
		autreTelephone:{validators:{numeric:{separator:",",message:messages.dpers.telephone}}},
		libelleFonctions:{validators:{regexp:{regexp:h,message:messages.dpers.numeric},notEmpty:{message:messages.dpers.libelleFonctionsRequis}}},
		residentFiscalFrancais:{validators:{notEmpty:{message:messages.dpers.fiscalite}}},
		
		revenusMensuelsNets:{validators:{regexp:{regexp:/^[0-9]+((\.|,)[0-9]{1,2})?$/},greaterThan:{value:function(){return"true"===$("#isCompteJoint").val()?0:"true"===$("#connected").val()?c:p},message:messages.dpers.revenusMinDav.replace("{0}",N(p)).replace("{1}",N(c)).replace("{2}",N(u)).replace("{3}",N(g)).replace("{4}",N(v))},notEmpty:{message:messages.dpers.revenusMensuelsRequis}}},
		
		montantPremierVersement:{validators:{regexp:{regexp:/^[0-9]+((\.|,)[0-9]{1,2})?$/},greaterThan:{value:function(){return"true"===$("#isCompteJoint").val()?0:"true"===$("#connected").val()?c:p},message:messages.dpers.montantVerMinDav.replace("{0}",N(p)).replace("{1}",N(c)).replace("{2}",N(u)).replace("{3}",N(g)).replace("{4}",N(v))},notEmpty:{message:messages.dpers.montantPremierVersementRequis}}},
		
		notifications:{validators:{notEmpty:{message:messages.dpers.notificationRequis}}},
		nonContribuableAmericain:{validators:{notEmpty:{message:messages.dpers.contribuableAmericainRequis}}},
		infosClient:{validators:{notEmpty:{message:messages.gdpr.infosClientRequis}}},
		natureContratTravail:{validators:{notEmpty:{message:messages.dpers.natureContratRequis}}},
		situationProfessionnelle:{validators:{notEmpty:{message:messages.dpers.situationProRequis}}},
		secteurActivite:{validators:{notEmpty:{message:messages.dpers.secteurRequis}}},
		situationFamiliale:{validators:{notEmpty:{message:messages.dpers.situationFamilialeRequis}}},
		revenusAnnuelsNets:{validators:{notEmpty:{message:messages.dpers.revenusAnnuelsRequis}}},
		patrimoineGlobal:{validators:{notEmpty:{message:messages.dpers.patrimoineRequis}}}}};

		function b(e,s,a,i){
			return t.isValidField(a)&&t.isValidField(i)&&t.isValidField(s)&&t.isValidField(e)
		}
		t=a.eersValidator(y),
		$("#autreTelephone, #telephonePortable").on("blur",function(){$(this).parent().find(".phone-error").remove()}),
		o.on("cut copy paste dragover",function(e){e.preventDefault()}),
		r.on("dragstart",function(e){e.preventDefault()}),
		o.attr("autocomplete","off"),a.find(".popovers").popover(),
		
		s.click(
			function(){
				$("#header-title").text("Premier titulaire"),
				$("#isCompteJoint").val("true"),
				$(this).removeClass("btn-light-grey").addClass("active"),
				e.removeClass("active").addClass("btn-light-grey"),
				$(".triangle").appendTo(s)
			}
		),
		
		e.click(
			function(){
				$("#header-title").text("Vos Informations"),
				$("#isCompteJoint").val("false"),
				$(this).removeClass("btn-light-grey").addClass("active"),
				s.removeClass("active").addClass("btn-light-grey"),
				$(".triangle").appendTo(e)
			}
		),
		a.find('input[name="civilite"]').on("ifChecked",
			function(e){
				var s=$(".maiden-group"),a=s.find('input[name="nomJeuneFille"]');"MME"===e.target.value?(s.removeClass("no-display").addClass("block"),t.addField(a)):($("#nomJeuneFille").val(""),s.removeClass("block").addClass("no-display"),t.getFieldElements(a.attr("name"))&&t.removeField(a))
			}
		);
		
		var x=function(){$.ajax({type:"post",url:window.location.pathname+"/create",data:{emailDuTitulaire:r.val(),nomDuTitulaire:l.val(),prenomDuTitulaire:m.val()}}).done(function(e){$("#idSous").val(e)})};function E(e){var s=$("#natureContratTravail"),a=s.closest(".form-group");-1!==i.indexOf($("#situationProfessionnelle").val())?(a.hide(),s.val("autre")):(a.show(),e||s.val(""))}function C(e,s,a){var i="<option value='{value}' {selected}>{text}</option>".split("{value}").join(e);return i=(i=i.split("{selected}").join(a?"selected='selected'":"")).split("{text}").join(s)}function q(){var e,s,a=!1,i=$("#villeNaissance").val().trim().toLowerCase(),t=$("#departementNaissance").val().trim();(!isConnected||isProspect)&&(s=t,"lyon"===(e=i)&&"69"===s||"marseille"===e&&"13"===s||"paris"===e&&"75"===s)&&(a=!0,function(e){for(var s=allArronndissements[e],a=C("",messages.dpers.arrondissementNaissanceEmpty,arrondissementNaissance),i=0;i<s.length;i++)a+=C(s[i].zipCode,s[i].name,arrondissementNaissance==s[i].zipCode);$("#arrondissementNaissanceSelect").empty().append(a)}(i)),a?$("#arrondissementNaissance").show():$("#arrondissementNaissance").hide()}function N(e){e+="";for(var s=/(\d+)(\d{3})/;s.test(e);)e=e.replace(s,"$1&nbsp;$2");return e}$(r.add(l).add(m).add(o)).blur(function(){b(l,m,r,o)&&!n.val()&&a.find('input[name="infosClient"]').is(":checked")&&x()}),a.find('input[name="infosClient"]').change(function(){this.checked&&b(l,m,r,o)&&!n.val()&&x()}),n.val()||""===l.val()||""===m.val()||""===r.val()||$.ajax({type:"post",url:window.location.pathname+"/create",data:{emailDuTitulaire:r.val(),nomDuTitulaire:l.val(),prenomDuTitulaire:m.val()}}).done(function(e){$("#idSous").val(e)}),$.ajax(window.location.pathname+"/ref/situationpro").done(function(e){i=e,E(!0)}),$("#situationProfessionnelle").change(function(){E(!1)}),$(r.add(l).add(m).add(o)).blur(function(){b(l,m,r,o)&&checkChatData(l,m,r,o)}),q(),$("#villeNaissance, #departementNaissance").change(function(){q()}),-1!==location.href.indexOf("idDemande")&&-1===location.href.indexOf("origin")?t.validate():l.is("[readonly]")&&a.find(":input:not([readonly])").each(function(){$(this).val()&&!$(this).is(":checkbox")&&t.validateField($(this))}),
			function(){var e,s=["paysNaissance","nationalite","pays","complementAdresse","autreTelephone","notifications"];for(e in s)t.validateField(s[e])}()	
});