
/**
 * mise à jour du champ isReadyForChat si les champs nom, prenom, email, confirmEmail sont renseignés
 * @param nom
 * @param prenom
 * @param email
 * @param confirmEmail
 */
function checkChatData(nom, prenom, email, confirmEmail) {
	if ($.trim(email.val()) != "" && $.trim(nom.val()) != "" && $.trim(prenom.val()) != "" && $.trim(confirmEmail.val()) != "") {
		$('#chat_nom').text(nom.val().toUpperCase());
    	$('#chat_prenom').text(prenom.val().toUpperCase());
    	$('#chat_email').text(email.val().toUpperCase());
    	$('#isReadyForChat').text(true);
    }
}

