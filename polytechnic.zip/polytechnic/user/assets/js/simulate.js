	
	function Mef(valeur){ 	
		return valeur.toFixed(2);	
	}
	
	function printdiv(divID){
		var headstr = "<html><head><title></title></head><body>";
		var footstr = "</body>";
		var newstr = document.all.item(divID).innerHTML;
		var oldstr = document.body.innerHTML;
		document.body.innerHTML = headstr+newstr+footstr;
		window.print();
		document.body.innerHTML = oldstr;
		return false;
	}

	
	function Calcul(recupMontant, recupDureeMois, tauxPret, tauxAssurance){ 
		recupDureeMois=recupDureeMois*12;
		var Rf = (tauxPret / 1200);
		var P1 = recupMontant * ( Rf / ( 1 - ( 1 / ( Math.pow ( ( 1 + Rf ), recupDureeMois ) ) ) ) ) ;
		var Pf = Math.floor ( ( P1 + 0.005 ) * 100) / 100; //mensualités
		
		mensualiteassurance=(recupMontant*tauxAssurance)/1200;
		couttotalassurance=mensualiteassurance*recupDureeMois;
		
		var Amort=new Array();
		Amort[0,1] = recupMontant;
		var Cp=0;
		var Ci=0;
		
		var impr=("<"+"table border='0' >");
		impr+=("<"+"tr><"+"th>Echéance</"+"th><"+"th>Année</"+"th>");
		impr+=("    <"+"th>Mois</"+"th>");
		impr+=("    <"+"th>Mensualité</"+"th>");
		impr+=("    <"+"th>Dont Capital</"+"th><"+"th>Dont Intérêt</"+"th>");
		impr+=("    <"+"th>Capital restant dû</"+"th></"+"tr>");
		
		
		for ( var I=1 ; I <= recupDureeMois ; I++ ){	
			Amort[I, 2] = Amort[I - 1, 1] * Rf;
			Amort[I, 2] = Math.floor((Amort[I, 2] + 0.005) * 100) / 100;
			Amort[I, 1] = Amort[I - 1, 1] - Pf + Amort[I, 2];
			Amort[I, 1] = Math.floor ( ( Amort[I, 1] + 0.005 ) * 100 ) / 100;
			
			if(I==recupDureeMois) {Amort[I, 1] = 0;}
			
			var T1 = I - Math.floor ( ( I - 1 ) / 12 ) * 12;
			var T2 = 1 + Math.floor ( ( I - 1 ) / 12 );
			
			impr+=("<"+"tr><"+"td>"+I+"</"+"td>"); //mois
			impr+=("    <"+"td>"+T2+"</"+"td>");
			impr+=("    <"+"td>"+T1+"</"+"td>");
			impr+=("    <"+"td>"+Pf+"</"+"td>");
			impr+=("    <"+"td>"+Mef(Pf - Amort[I, 2])+"</"+"td>");
			impr+=("    <"+"td>"+Mef(Amort[I,2])+"</"+"td>");
			impr+=("    <"+"td>"+Mef(Amort[I, 1])+"</"+"td>");
			
			Cp = Cp + Pf - Amort[I, 2];
			Ci = Ci + Amort[I, 2];
		}
		
		Cp = Math.floor((Cp + 0.005) * 100) / 100;
		Ci = Math.floor((Ci + 0.005) * 100) / 100;
		
		
		document.getElementById("mensualite").innerHTML=Pf+'&nbsp;€';
		document.getElementById("montanttotaldu").innerHTML=Mef(Pf*recupDureeMois)+'&nbsp;€';
		
		document.getElementById("mensualit").innerHTML=Pf+'&nbsp;€';
		document.getElementById("couttotalassu").innerHTML=Mef(couttotalassurance)+'&nbsp;€';
		document.getElementById("couttotalassu2").innerHTML=Mef(couttotalassurance)+'&nbsp;€';
		document.getElementById("cotmensuel").innerHTML=Mef(couttotalassurance/recupDureeMois)+'&nbsp;€';
		
		
		// document.getElementById("tau").innerHTML=tauxPret+'&nbsp;%';
		document.getElementById("montanttotald").innerHTML=Mef(Pf*recupDureeMois)+'&nbsp;€';
		
		document.getElementById("mensualiteassu").innerHTML=Mef(mensualiteassurance+Pf)+'&nbsp;€';
		document.getElementById("montanttotatassu").innerHTML=Mef(couttotalassurance+Pf*recupDureeMois)+'&nbsp;€';
		
		document.getElementById("result").innerHTML=impr;
	}
	
	
	
	
	
	
	function printContent(el){
		var restorepage = document.body.innerHTML;
		var printcontent = document.getElementById(el).innerHTML;
		document.body.innerHTML = printcontent;
		window.print();
		document.body.innerHTML = restorepage;
	}